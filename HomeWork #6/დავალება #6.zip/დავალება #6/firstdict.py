dict1={i:i**2 for i in range(1,11)}

print(dict1)


