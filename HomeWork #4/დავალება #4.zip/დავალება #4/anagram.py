print("This soft will help you to find out, are the words you choose are anagram")

word1= input("Input first word:").lower()
word2=input("Input second word:").lower()

if len(word1)!=len(word2):
    print("Your choosen words are not anagram")
else:
    for char in word1:
         if char in word2:
          print(f"{word1} and {word2} are anagram")
          break
         else:
          print(f"{word1} and {word2} are not anagram")
          break
         

        



