list1 = [(1, 3), (4, 2), (2, 5)]

print(sorted(list1, key=lambda i: i[1]))

